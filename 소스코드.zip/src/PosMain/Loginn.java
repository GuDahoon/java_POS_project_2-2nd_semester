package PosMain;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.Calendar;

import PosChat.ChatGUIClientt;
import PosChat.ChatGUICounterr;
import PosChat.ChatGUIServer;
import PosChat.RunServerThread;

// 마찬가지로 JFrame을 이용하여 만들고 있습니다.
public class Loginn extends JFrame {

	JTextField JT_ID; // ID 택스트 필드
	JPasswordField JP_PW; // PW 텍스트 필드

	JButton login = new JButton("");
	JButton signUp = new JButton("");
	JLabel clock = new JLabel();
	ImageIcon icon;

	public Loginn() {
		setIconImage(
				Toolkit.getDefaultToolkit().getImage("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\beer.png")); // Login
																														// 생성자
		icon = new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\loginbackground.jpg");
		setTitle("POS기 로그인"); // title 지정
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 686, 510);
		setLocationRelativeTo(null); // 창이 가운데에 나오게
		JPanel panel = new JPanel() {
			public void paintComponent(Graphics g) {
				g.drawImage(icon.getImage(), 0, 0, null);
				setOpaque(false);
				super.paintComponent(g);
			}
		}; // 전체 패널
		panel.setBackground(Color.WHITE);
		getContentPane().setBackground(Color.white);
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		JLabel titleLabel = new JLabel("");
		titleLabel        
				.setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\PosLogin.png"));
		titleLabel.setForeground(SystemColor.inactiveCaptionBorder);
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setFont(new Font("휴먼매직체", Font.BOLD, 40));

		TimerThreadd ttclock = new TimerThreadd(clock);
		ttclock.start();
		clock.setBounds(400, 300, 120, 35);

		titleLabel.setBounds(104, 70, 460, 97);
		panel.add(titleLabel);

		JLabel IDLabel = new JLabel("");
		IDLabel.setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\ID.png"));
		IDLabel.setForeground(new Color(255, 240, 245));
		IDLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		IDLabel.setFont(new Font("맑은 고딕", Font.BOLD, 30));
		IDLabel.setBounds(195, 167, 100, 50);
		panel.add(IDLabel);
		JT_ID = new JTextField();
		JT_ID.setBounds(287, 177, 120, 35);
		panel.add(JT_ID);
		JT_ID.setColumns(10);

		JLabel PWDLabel = new JLabel("");
		PWDLabel.setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\pw.png"));
		PWDLabel.setForeground(new Color(255, 240, 245));
		PWDLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		PWDLabel.setFont(new Font("맑은 고딕", Font.BOLD, 30));
		PWDLabel.setBounds(185, 227, 100, 50);
		panel.add(PWDLabel);
		JP_PW = new JPasswordField();
		JP_PW.setBounds(287, 232, 120, 35);
		panel.add(JP_PW);
		login.setForeground(new Color(255, 255, 255));
		login.setBorderPainted(false);
		login.setContentAreaFilled(false);
		login.setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\login.png"));
		login.setFont(new Font("휴먼매직체", Font.PLAIN, 20));
		login.setBackground(new Color(255, 255, 255));
		// 로그인 기능
		// mariaDB와 연결하여 성공여부 알려준다.
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					boolean loginOk;
					UserDaoo login = UserDaoo.getInstance();
					loginOk = login.loginCheck(JT_ID.getText(), new String(JP_PW.getPassword()));
					if (loginOk) { // loginOk가 true일 경우
						login.loginSuccess(JT_ID.getText()); // getInstance() 메소드를 통해 한번만 생성된 객체를 불러옴
						JOptionPane.showMessageDialog(null, "로그인성공"); // 메세지 출력
						dispose(); // 로그인 창 닫기
					} else { // 그 외의 경우
						JOptionPane.showMessageDialog(null, "로그인실패!!\n" + "아이디와 비밀번호를 확인해주세요!");
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		login.setBounds(180, 321, 100, 40);
		panel.add(login);
		
		
		signUp.setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\signup.png"));
		signUp.setFont(new Font("휴먼매직체", Font.PLAIN, 20));
		signUp.setBackground(Color.ORANGE);
		signUp.setBorderPainted(false);
		signUp.setContentAreaFilled(false);
		signUp.addActionListener(new ActionListener() { // 회원가입 이벤트 처리
			public void actionPerformed(ActionEvent e) {
				MemberSignupp frame = new MemberSignupp(); // 버튼 눌렀을 시 회원가입 창 출력
				frame.setVisible(true); // 회원가입 창 출력
			}
		});
		signUp.setBounds(388, 321, 100, 40);
		panel.add(signUp);
		
		JLabel version = new JLabel("");
		version.setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\version.png"));
		version.setBounds(505, 433, 158, 35);
		panel.add(version);
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() { // 동작을 위한 함수
				Loginn frame = new Loginn();
				try {
					//Login frame = new Login(); // 로그인 프레임 생성
					frame.setVisible(true); // 프레임 생성
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}