package PosMain;

import java.sql.*; // jdbc 패키지 사용을 위해 import

public class MariaDbConnectt {
	private static MariaDbConnectt MariaDbConnect = new MariaDbConnectt(); // 마리아DB에 접근하기 위한 객체 생성
	Connection con = null; // 연결값을 null값으로 초기화

	private MariaDbConnectt() {
	} // 기본 생성자

	public static MariaDbConnectt getInstance() {
		if (MariaDbConnect == null) {
			MariaDbConnect = new MariaDbConnectt();
		}
		return MariaDbConnect;
	}

	public Connection getConnection() { // 마리아DB 서버에 접근하기 위한 구문
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			String url = "jdbc:mariadb://localhost:3306/test";
			con = DriverManager.getConnection(url, "root", "ekgns123");
			if(con != null) {
				System.out.println("DB 접속 성공");
			}
		} catch(ClassNotFoundException e) {
			System.out.println("드라이버 로드 실패");
		} catch(SQLException e) {
			System.out.println("DB 접속 실패");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public static void main(String[] args) {
		MariaDbConnectt dbcon = new MariaDbConnectt();
	}
}

