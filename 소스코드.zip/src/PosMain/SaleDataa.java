package PosMain;

public class SaleDataa {
	public String saleid;
	public String date;
	public String total;
	
	public String getsaleId() {
		return saleid;
	}
	public void setsaleId(String saleid) {
		this.saleid = saleid;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
}
    