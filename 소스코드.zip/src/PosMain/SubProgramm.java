package PosMain;

import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Vector; // 
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableStringConverter;

class SubProgramm extends JDialog {
   // 좌측 패널
   JPanel left = new JPanel(); // 계산기와 음식 메뉴 합계 나오는 부분
   JPanel leftTop = new JPanel(); // 음식 메뉴 합계 나오는 부분
   JPanel leftTopTop = new JPanel();
   JPanel leftTopBottom = new JPanel();
   JPanel leftBottom = new JPanel(); // 음식 총금액 계산기 나오는 부분
   JPanel leftBottomLeft = new JPanel(); // 음식 총금액 나오는 부분
   JPanel leftBottomRight = new JPanel(); // 계산기 나오는 부분
   // 우측 패널
   JPanel rightmenu1 = new JPanel(); // 탕류 패널이 들어갈 부분
   JPanel rightmenu2 = new JPanel(); // 볶음류 패널이 들어갈 부분
   JPanel rightmenu3 = new JPanel(); // 마른안주 패널이 들어갈 부분
   JPanel rightmenu4 = new JPanel(); // 음료 패널이 들어갈 부분
   JPanel right = new JPanel(); // 오른쪽 메뉴,주문 버튼 있는 부분
   JPanel rightTop = new JPanel(); // 메뉴 나오는 부분
   JPanel rightBottom = new JPanel(); // 옵션(주문, 선택취소, 전체취소, 창닫기) 부분이 들어갈 부분
   // 고기, 식사, 음료 라벨 설정  
   JLabel menu1 = new JLabel("국물류"); 
   JLabel menu2 = new JLabel("볶음류");
   JLabel menu3 = new JLabel("마른안주");
   JLabel menu4 = new JLabel("술/음료");

   JPanel menu = new JPanel(); // 음식 메뉴 선택 부분
   JPanel calculator = new JPanel(); // 계산기
   // 각 메뉴를 배열로 생성
   String[][] menuSoup = { {"어묵탕", "10000원"}, {"해물탕","12000원"}, {"짬뽕탕","12000원"}, {"김치찌개", "12000원"}, {"부대찌개", "12000원"} };
   String[][] menuBok = { {"소시지볶음", "8000원"}, {"닭갈비", "10000원"}, {"소고기숙주볶음", "15000원"}, {"골뱅이무침", "13000원"}, {"닭똥집볶음", "13000원"} };
   String[][] menuDry = { {"쥐포", "3000원"}, {"오징어입", "5000원"}, {"마른오징어", "5000원"}, {"오다리버터구이", "8000원"}, {"갑오징어", "12000원"} };
   String[][] menuDrink = { {"처음처럼", "4000원"}, {"참이슬", "4000원"}, {"카스", "4000원"}, {"하이트", "4000원"}, {"테라", "4000원"}, 
         {"생맥주300cc", "2000원"}, {"생맥주500cc", "3000원"}, {"생맥주1000cc", "6000원"}, {"생맥주3000cc", "15000원"}, {"음료", "1000원"} };
   // 메뉴별 가격 설정
   int[] priceSoup = { 10000, 12000, 12000, 12000, 12000 };
   int[] priceBok = { 8000, 10000, 15000, 13000, 13000 };
   int[] priceDry = { 3000, 5000, 5000, 8000, 12000 };
   int[] priceDrink = { 4000, 4000, 4000, 4000, 4000, 2000, 3000, 6000, 15000, 1000 };
   
   // 메뉴별 개수 설정
   int[] countSoup = { 0, 0, 0, 0, 0};
   int[] countBok = { 0, 0, 0, 0, 0};
   int[] countDry = { 0, 0, 0, 0, 0};
   int[] countDrink = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
   // 각 메뉴 패널 한 행당 5열씩 존재하도록 선언
   JPanel rightTopTop = new JPanel(new GridLayout(menuSoup.length % 5, 5)); // 국물류 메뉴
   JPanel rightTopCenter = new JPanel(new GridLayout(menuBok.length % 5, 5)); // 볶음류 메뉴
   JPanel rightTopBottom = new JPanel(new GridLayout(menuDry.length % 5, 5)); // 마른안주 메뉴
   JPanel rightTopBelow = new JPanel(new GridLayout(menuDrink.length % 5, 5)); // 음료 메뉴
   // 옵션버튼 배열로 생성
   String[] option = { "주문", "선택취소", "전체취소", "창닫기" };
   JButton[] optionButton = new JButton[4];
   // 왼쪽 메뉴, 가격 테이블 생성 및 표현
   String[] ColName = { "메뉴", "수량", "가격" };
   String[][] Data;
   // 모델과 데이터를 연결해준다. 
   DefaultTableModel model = new DefaultTableModel(Data, ColName) {
      public boolean isCellEditable(int row, int column) {
         return false;
      }
   };
   JTable jTable = new JTable(model); // 영수증 테이블

   // 각 메뉴의 길이만큼 메뉴 버튼 생성
   JButton[] menuSoupbtn = new JButton[menuSoup.length];
   JButton[] menuBokbtn = new JButton[menuBok.length];
   JButton[] menuDrybtn = new JButton[menuDry.length];
   JButton[] menuDrinkbtn = new JButton[menuDrink.length];
   // 총 가격 라벨 생성
   JLabel totalLbl = new JLabel("총 가격 : ");
   //
   JTextField totalFld = new JTextField(20);
   
   int totalPrice;
   Vector<Integer> v = new Vector<Integer>();// 합을 위한 벡터
   Vector<String> s = new Vector<String>();
   String a;
   String n = "";
   int minus; // 선택취소를 위한 변수
   int hap;
   // SubProgram 생성자(frame, title 선언)
   public SubProgramm(JFrame frame, String title) {
      super(frame, title, true);
      setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\beer.png"));
      setTitle("Menu");
      setResizable(false);
      setAlwaysOnTop(false);
      setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
      getContentPane().setLayout(new BorderLayout());
      // 백그라운드 색 지정
      setBackground(new Color(0, 0, 0));
      left.setBackground(new Color(0, 0, 0));
      leftTop.setBackground(new Color(0, 0, 0));
      leftTopTop.setBackground(new Color(0, 0, 0));
      leftTopBottom.setBackground(new Color(0, 0, 0));
      right.setBackground(new Color(0, 0, 0));
      left.setLayout(new BorderLayout()); // 계산기와 음식 메뉴 합계 나오는 부분
      rightTop.setBackground(new Color(0, 0, 0));

      rightTop.setLayout(new GridLayout(8, 5, 5, 5)); // 오른쪽 메뉴,옵션 버튼 있는 부분
      rightBottom.setLayout(new GridLayout(1, 5, 5, 5));
      rightBottom.setBackground(new Color(0,0,0));

      leftBottom.setLayout(new BorderLayout()); // 음식 총금액 계산기 나오는 부분 레이아웃
      leftTop.setLayout(new BorderLayout()); // 영수증 부분(주문내역)

      right.setLayout(new BorderLayout());
      totalFld.setEditable(false);
      totalFld.setSize(700, 70);
      jTable.getTableHeader().setFont(new Font("한컴바탕", Font.BOLD, 15));
      jTable.setRowHeight(35);
      JScrollPane tableScroll = new JScrollPane(jTable);
      tableScroll.setPreferredSize(new Dimension(600, 700));
      // 오른쪽 상단에 고기 메뉴 버튼 추가
      // 배경색과 폰트 지정
      for (int i = 0; i < menuSoup.length; i++) {
         rightTopTop.add(menuSoupbtn[i] = new JButton(menuSoup[i][0]));
         menuSoupbtn[i].setBackground(Color.WHITE);
         menuSoupbtn[i].setFont(new Font("한컴바탕", Font.BOLD, 20));
      }
      
      // 오른쪽 상단에 음식 메뉴 버튼 추가
      // 배경색과 폰트 지정
      for (int i = 0; i < menuBok.length; i++) {
         rightTopCenter.add(menuBokbtn[i] = new JButton(menuBok[i][0]));
         menuBokbtn[i].setBackground(Color.WHITE);
         menuBokbtn[i].setFont(new Font("한컴바탕", Font.BOLD, 20));
      }
      
      for (int i = 0; i < menuBok.length; i++) {
         rightTopBottom.add(menuDrybtn[i] = new JButton(menuDry[i][0]));
         menuDrybtn[i].setBackground(Color.WHITE);
         menuDrybtn[i].setFont(new Font("한컴바탕", Font.BOLD, 20));
      }
      
      // 오른쪽 상단에 주류 메뉴 버튼 추가
      // 배경색과 폰트 지정
      for (int i = 0; i < menuDrink.length; i++) {
         rightTopBelow.add(menuDrinkbtn[i] = new JButton(menuDrink[i][0]));
         menuDrinkbtn[i].setBackground(Color.WHITE);
         menuDrinkbtn[i].setFont(new Font("한컴바탕", Font.BOLD, 20));
      }
      // 오른쪽 하단에 옵션버튼 추가
      // 배경색과 폰트 지정
      for (int i = 0; i < optionButton.length; i++) {
         rightBottom.add(optionButton[i] = new JButton(option[i]));
         optionButton[i].setBackground(new Color(102,102,102));
         optionButton[i].setForeground(Color.BLACK);
         optionButton[i].setFont(new Font("한컴바탕", Font.BOLD, 20));
      }

      leftTopTop.add(tableScroll); // 텍스트에리어 추가
      totalLbl.setForeground(new Color(240, 248, 255));
      totalLbl.setFont(new Font("한컴바탕", Font.BOLD, 30));
      totalFld.setFont(new Font("한컴바탕", Font.BOLD, 30));
      leftTopBottom.add(totalLbl); // 
      leftTopBottom.add(totalFld);
      leftBottom.add(leftBottomLeft, BorderLayout.WEST);
      leftBottom.add(leftBottomRight, BorderLayout.EAST);
      leftTop.add(leftTopTop, BorderLayout.CENTER);
      leftTop.add(leftTopBottom, BorderLayout.SOUTH);
      left.add(leftTop, BorderLayout.NORTH);
      left.add(leftBottom, BorderLayout.SOUTH);

      right.add(rightTop, BorderLayout.CENTER);
      rightmenu1.setBackground(new Color(0, 0, 0));
      
      // 고기메뉴 패널 추가
      rightTop.add(rightmenu1, BorderLayout.NORTH);
      menu1.setForeground(new Color(240, 248, 255));
      rightmenu1.add(menu1);
      menu1.setFont(new Font("한컴바탕", Font.BOLD, 30));
      rightTopTop.setBackground(new Color(0, 0, 0));
      rightTop.add(rightTopTop, BorderLayout.NORTH);
      rightmenu2.setBackground(new Color(0, 0, 0));
      // 음식메뉴 패널 추가 
      rightTop.add(rightmenu2, BorderLayout.CENTER);
      menu2.setForeground(new Color(240, 248, 255));
      rightmenu2.add(menu2);
      menu2.setFont(new Font("한컴바탕", Font.BOLD, 30));
      rightTopCenter.setBackground(new Color(0, 0, 0));
      rightTop.add(rightTopCenter, BorderLayout.CENTER);
      rightmenu3.setBackground(new Color(0, 0, 0));
      // 주류메뉴 패널 추가
      rightTop.add(rightmenu3, BorderLayout.SOUTH);
      menu3.setForeground(new Color(240, 248, 255));
      rightmenu3.add(menu3);
      menu3.setFont(new Font("한컴바탕", Font.BOLD, 30));
      menu3.setHorizontalAlignment(JLabel.LEFT);
      rightTopBottom.setBackground(new Color(0, 0, 0));
      rightTop.add(rightTopBottom, BorderLayout.SOUTH);
      rightmenu4.setBackground(new Color(0, 0, 0));
      // ㅁㄴㅇ
      rightTop.add(rightmenu4, BorderLayout.SOUTH);
      menu4.setForeground(new Color(240, 248, 255));
      rightmenu4.add(menu4);
      menu4.setFont(new Font("한컴바탕", Font.BOLD, 30));
      menu4.setHorizontalAlignment(JLabel.LEFT);
      rightTopBelow.setBackground(new Color(0, 0, 0));
      rightTop.add(rightTopBelow, BorderLayout.SOUTH);
      right.add(rightBottom, BorderLayout.SOUTH);
      
      // 고기메뉴버튼의 개수만큼 이벤트 처리
      totalFld.setText(Integer.toString(totalPrice) + "원");
      for (int i = 0; i < menuSoupbtn.length; i++) {
         int index = i;
         menuSoupbtn[i].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               int totalRow = jTable.getRowCount();
               countSoup[index]++;
               JButton menuButton = (JButton) e.getSource(); // getSource() 메소드를 사용해서 특정 컨테이너의 모든 속성을 가져옴
               DefaultTableModel m = (DefaultTableModel) jTable.getModel();// defaultTablemodel 클래스를 통해 addRow 함수를 사용 할 수 있게 함
               for(int w = 0; w < totalRow; w++) {
                  if(menuSoup[index][0] == m.getValueAt(w, 0)) {
                     totalPrice = totalPrice - (int) m.getValueAt(w, 2);
                     m.removeRow(w);
                     break;
                  }
               }
               m.addRow(new Object[] { menuSoup[index][0], countSoup[index], countSoup[index] * priceSoup[index] }); // addRow()함수를 통해 JTable에 고기메뉴의 이름과 가격을 추가
               tableScroll.getVerticalScrollBar().setValue(tableScroll.getVerticalScrollBar().getMaximum());
               totalPrice = totalPrice + (countSoup[index] * priceSoup[index]); // 총 가격에 선택된 고기의 가격을 더해서 반환
               totalFld.setText(Integer.toString(totalPrice) + "원");
            }
         });
      }
      
      for (int i = 0; i < menuDrybtn.length; i++) {
         int index = i;
         menuDrybtn[i].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               int totalRow = jTable.getRowCount();
               countDry[index]++;
               JButton menuButton = (JButton) e.getSource();
               DefaultTableModel m = (DefaultTableModel) jTable.getModel();
               for(int w = 0; w < totalRow; w++) {
                  if(menuDry[index][0] == m.getValueAt(w, 0)) {
                     totalPrice = totalPrice - (int) m.getValueAt(w, 2);
                     m.removeRow(w);
                     break;
                  }
               }
               m.addRow(new Object[] { menuDry[index][0], countDry[index], countDry[index] * priceDry[index] });
               tableScroll.getVerticalScrollBar().setValue(tableScroll.getVerticalScrollBar().getMaximum());
               totalPrice = totalPrice + (countDry[index] * priceDry[index]);
               totalFld.setText(Integer.toString(totalPrice) + "원");
            }
         });
      }
      
      // 음식메뉴버튼의 개수만큼 이벤트 처리(고기메뉴버튼의 형식과 동일)
      for (int i = 0; i < menuBokbtn.length; i++) {
         int index = i;
         menuBokbtn[i].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               int totalRow = jTable.getRowCount();
               countBok[index]++;
               JButton menuButton = (JButton) e.getSource();
               DefaultTableModel m = (DefaultTableModel) jTable.getModel();
               for(int w = 0; w < totalRow; w++) {
                  if(menuBok[index][0] == m.getValueAt(w, 0)) {
                     totalPrice = totalPrice - (int) m.getValueAt(w, 2);
                     m.removeRow(w);
                     break;
                  }
               }
               m.addRow(new Object[] { menuBok[index][0], countBok[index], countBok[index] * priceBok[index] });
               tableScroll.getVerticalScrollBar().setValue(tableScroll.getVerticalScrollBar().getMaximum());
               totalPrice = totalPrice + (countBok[index] * priceBok[index]);
               totalFld.setText(Integer.toString(totalPrice) + "원");
            }
         });
      }
      // 주류메뉴버튼의 개수만큼 이벤트 처리(고기메뉴버튼의 형식과 동일)
      for (int i = 0; i < menuDrinkbtn.length; i++) {
         int index = i;
         menuDrinkbtn[i].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               int totalRow = jTable.getRowCount();
               countDrink[index]++;
               JButton menuButton = (JButton) e.getSource();
               DefaultTableModel m = (DefaultTableModel) jTable.getModel();
               for(int w = 0; w < totalRow; w++) {
                  if(menuDrink[index][0] == m.getValueAt(w, 0)) {
                     totalPrice = totalPrice - (int) m.getValueAt(w, 2);
                     m.removeRow(w);
                     break;
                  }
               }
               m.addRow(new Object[] { menuDrink[index][0], countDrink[index], countDrink[index] * priceDrink[index] });
               tableScroll.getVerticalScrollBar().setValue(tableScroll.getVerticalScrollBar().getMaximum());
               totalPrice = totalPrice + (countDrink[index] * priceDrink[index]);
               totalFld.setText(Integer.toString(totalPrice) + "원");         
            }
         });
      }
      getContentPane().add(left, BorderLayout.WEST);
      getContentPane().add(right, BorderLayout.CENTER);
      setSize(1700, 800);
      // 주문버튼 리스너 설정
      optionButton[0].addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            DefaultTableModel m = (DefaultTableModel) jTable.getModel(); // DefaultTableModel  메소드 활용
            v.add(totalPrice); // 합을 위한 벡터 v에 총 가격 추가
            totalPrice = 0; // 총 가격 0으로 초기화
            for (int i = 0; i < jTable.getRowCount(); i++) {
               s.add((m.getValueAt(i, 0).toString()) + "\t" + (m.getValueAt(i, 1).toString()) + "개" + "\n"); 
            }
            for (int i = 0; i < s.size(); i++) { // 벡터 객체 s의 사이즈만큼 반복문 실행
               n += s.get(i); // 벡터 객체의 
               //System.out.println(n);
            }
            setVisible(false); // 주문버튼 클릭 시 창 닫음
            for(int n = 0; n<countSoup.length; n++)
               countSoup[n] = 0;
            for(int n = 0; n<countBok.length; n++)
               countBok[n] = 0;
            for(int n = 0; n<countDrink.length; n++)
               countDrink[n] = 0;
         }
      });
      optionButton[1].addActionListener(new ActionListener() { // 선택취소 버튼
         @Override
         public void actionPerformed(ActionEvent e) {
            int confirmResult = JOptionPane.showConfirmDialog(null, "선택한 주문을 취소하시겠습니까?", "주문 취소" ,JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if(confirmResult == JOptionPane.YES_OPTION) {
               DefaultTableModel m = (DefaultTableModel) jTable.getModel();
               int row = jTable.getSelectedRow(); // JTable의 열 값을 가져옴
               int col = jTable.getSelectedColumn(); // JTable의 행 값을 가져옴
               if(col == 0)
                  minus = (int) m.getValueAt(row, col+2); // minus 변수 초기화 getValueAt() 메소드를 통해 원하는 위치의 데이터를 가져옴
               else if(col == 1)
                  minus = (int) m.getValueAt(row, col+1);
               else
                  minus = (int) m.getValueAt(row, col);
               totalPrice = totalPrice - minus; // 총 가격에서 선택한 메뉴의 값을 빼준다.
               totalFld.setText(Integer.toString(totalPrice) + "원"); // 토탈필드의 텍스트 초기화
               m.removeRow(jTable.getSelectedRow());  // 선택된 열 삭제
            }
         }
      });
      optionButton[2].addActionListener(new ActionListener() { // 전체취소 버튼
         @Override
         public void actionPerformed(ActionEvent e) {
            int confirmResult = JOptionPane.showConfirmDialog(null, "전체 주문을 취소하시겠습니까?", "주문 취소" ,JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if(confirmResult == JOptionPane.YES_OPTION) {
               DefaultTableModel m = (DefaultTableModel) jTable.getModel(); // defaultTableModel 사용하여 jTable
               m.setRowCount(0);
               totalFld.setText(String.valueOf("")); // 토탈 필드를 빈 값으로 초기화
               totalPrice = 0; // 총 가격 0으로 초기화
               for(int i = 0; i<countSoup.length; i++) 
                  countSoup[i] = 0;
               for(int j = 0; j<countBok.length; j++) 
                  countBok[j] = 0;
               for(int k = 0; k<countDrink.length; k++)
                  countDrink[k] = 0;
            }
         }
      });
      optionButton[3].addActionListener(new ActionListener() { // 창닫기 버튼
         @Override
         public void actionPerformed(ActionEvent e) {
            DefaultTableModel m = (DefaultTableModel) jTable.getModel();
            m.setRowCount(0);
            totalFld.setText(String.valueOf(""));
            totalPrice = 0;
            setVisible(false);
         }
      });
      setLocationRelativeTo(null);
   }
   public String getInputMenuTotal() { // 총 주문메뉴 반환
      DefaultTableModel m = (DefaultTableModel) jTable.getModel();
      m.setRowCount(0);
      s.clear();
      return n;
   }

   public String getInputTotalFld() {
      if (totalFld.getText().length() == 0) // 만약 토탈 필드의 길이가 0이면
         return null; // null값 리턴
      else { // 그 외의 경우
         String totalString = totalFld.getText(); // 토탈 필드의 텍스트를 불러옴
         int lastNum = totalString.length();
         return totalString.substring(0, (lastNum-1)); // 리턴
      }
   }
}