package PosMain;

import java.awt.EventQueue;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

public class SaleDaoo {
	private static SaleDaoo sd = new SaleDaoo();
	public MariaDbConnectt mariaDbConnect = MariaDbConnectt.getInstance();
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	SaleDataa sale;
	ArrayList<SaleDataa> saleList; // 유저의 데이터 구조체 생성(유저의 데이터가 각자 다르기 떼문에 선언)
	String userid;
	
	public void setuserID(String id) {
		this.userid = id;
		System.out.println("현재 사용자의 id는 " + id);
	}
	
	public static SaleDaoo getInstance() {
		if(sd == null) {
			sd = new SaleDaoo();
		}
		return sd;
	}
	
	public ArrayList<SaleDataa> select() throws Exception {
		con = mariaDbConnect.getConnection();
		String sql = "SELECT * FROM testsale";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		saleList = new ArrayList<>();
		while(rs.next()) {
			sale = new SaleDataa();
			sale.setsaleId(rs.getString("testid__"));
			sale.setDate(rs.getString("testdate"));
			sale.setTotal(rs.getString("testtotal"));
			saleList.add(sale);
		}
		return saleList;
	}
	
	public boolean totalCheck(String id, String date) throws Exception {
		con = mariaDbConnect.getConnection(); // db에 접근
		saleList = this.select(); // 
		boolean saleOk = false; // loginOk를 false로 초기화
		for (SaleDataa sale : saleList) {
			if (id.equals(sale.getsaleId()) && date.equals(sale.getDate())) // 만약 입력된 아이디와 비밀번호가 유저의 아이디와 비밀번호와 같으면
				return saleOk = true; // loginOk를 true로 초기화 시켜준다.
		}
		return saleOk; // loginOk 리턴
	}
	
//	public ArrayList<SaleDataa> totalfind(String date) {
//		ArrayList<SaleDataa> list = new ArrayList<SaleDataa>();
//		try {
//			con = mariaDbConnect.getConnection();
//			String sql = "SELECT * FROM testsale";
//			pstmt = con.prepareStatement(sql);
//			pstmt.setString(1, date);
//			rs = pstmt.executeQuery();
//			while(rs.next()) {
//				SaleDataa sd = new SaleDataa();
//				sd.setsaleId(rs.getString(1));
//				sd.setDate(rs.getString(2));
//				sd.setTotal(rs.getString(3));
//				
//				list.add(sd);
//			}
//		} catch(Exception ex) {
//			System.out.println(ex.getMessage());
//		}
//		return list;
//	}
	
	public Vector<SaleDataa> GetAllSellTotal() {//db에서 데이터를 받아서 벡터로 반환하는 메소드
		//모든 상품 목록들을 리턴한다.
		String sql = "SELECT * FROM testsale" ;
		Vector<SaleDataa> lists = new Vector<SaleDataa>();
		try {
			con = mariaDbConnect.getConnection();
			pstmt = con.prepareStatement(sql) ; 
			rs = pstmt.executeQuery() ;
			while(rs.next()){
				SaleDataa sd = new SaleDataa();
				sd.setsaleId(rs.getString("testid__"));
				sd.setDate(rs.getString("testdate"));
				sd.setTotal(rs.getString("testtotal"));
				
				lists.add(sd) ;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lists ;
	}//GetAllSellList
	
	public int insert(String id, String date, String total) {
		con = mariaDbConnect.getConnection();
		int saleOk;
		try {
			String sql = "INSERT INTO testsale VALUES ('" + id + "','" + date + "','" + total + "')";
			pstmt = con.prepareStatement(sql);
			saleOk = pstmt.executeUpdate();
		} catch(Exception e) {
			return saleOk = 0;
		}
		return saleOk;
	}
}
