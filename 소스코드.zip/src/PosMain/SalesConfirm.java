package PosMain;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.util.Calendar;
import java.util.*;
import java.sql.*;
import java.util.Vector;
import java.util.ArrayList;

// 마찬가지로 JFrame을 이용하여 만들고 있습니다.
public class SalesConfirm extends JFrame {
	JLabel clock = new JLabel();
	private JTable table;
	private String saleconfirmid;
	DefaultTableModel model;
	Vector<SaleDataa> rowdata;
	SaleDaoo sd ;
	private JTextField datetf;
	
	public SalesConfirm() {}

	public SalesConfirm(String id) {
		this.saleconfirmid = id;
		System.out.println(saleconfirmid + " Hello Nice to meet you iamkdh1");
		setIconImage(
				Toolkit.getDefaultToolkit().getImage("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\beer.png")); // Login
																														// 생성자
		setTitle("Triple H 매출확인"); // title 지정
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 550, 450);
		setLocationRelativeTo(null); // 창이 가운데에 나오게
		JPanel panel = new JPanel(); // 전체 패널
		panel.setBackground(Color.BLACK);
		getContentPane().setBackground(Color.white);
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel BSL = new JLabel("사업자ID : ");
		BSL.setForeground(Color.WHITE);
		BSL.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		BSL.setBounds(30, 80, 120, 35);
		panel.add(BSL);
		
		JLabel lblNewLabel = new JLabel("Triple H Beer 매출확인");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("맑은 고딕", Font.BOLD, 30));
		lblNewLabel.setBounds(113, 25, 324, 40);
		panel.add(lblNewLabel);
		
		String [] title = {"사용자ID", "날짜", "총 판매액"};
		String [][] data = new String[0][3];
		model = new DefaultTableModel(data, title);
		table = new JTable(model);
		JScrollPane tablescroll = new JScrollPane(table);
		tablescroll.setBounds(63, 170, 409, 170);
		panel.add(tablescroll);
		
		JButton saleconfirmexit = new JButton("창닫기");
		saleconfirmexit.setBackground(new Color(204, 204, 204));
		saleconfirmexit.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		saleconfirmexit.setBounds(425, 361, 97, 40);
		saleconfirmexit.setForeground(Color.BLACK);
		panel.add(saleconfirmexit);
		
		JLabel idlabel = new JLabel(id);
		idlabel.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		idlabel.setForeground(Color.WHITE);
		idlabel.setBackground(Color.WHITE);
		idlabel.setBounds(150, 80, 200, 35);
		panel.add(idlabel);
		
		JButton fullLookup = new JButton("전체조회");
		fullLookup.setBackground(new Color(204,204,204));
		fullLookup.setForeground(Color.BLACK);
		fullLookup.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		sd = new SaleDaoo();
		rowdata = sd.GetAllSellTotal();
		fullLookup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					rowdata = sd.GetAllSellTotal();
					System.out.println("현재 매출 확인 아이디는 " + rowdata.get(0).saleid);
					for(int i=0; i<rowdata.size(); i++) {
						System.out.println("id는 " + rowdata.get(i).saleid + " 날짜는 " + rowdata.get(i).date
								+ " 총 판매액은 " + rowdata.get(i).total);
						String total [] = new String [3];
						if(saleconfirmid.equals(rowdata.get(i).saleid)) {
							total[0] = rowdata.get(i).saleid;
							total[1] = rowdata.get(i).date;
							total[2] = rowdata.get(i).total;
							System.out.println(Arrays.toString(total));
							model.addRow(total);
						}
					}
				} catch(Exception ee) {
					ee.printStackTrace();
				}
			}
		});
		fullLookup.setBounds(190, 355, 115, 30);
		panel.add(fullLookup);
		
		JButton resetbtn = new JButton("Reset");
		resetbtn.setForeground(Color.BLACK);
		resetbtn.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		resetbtn.setBackground(new Color(204, 204, 204));
		resetbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.setNumRows(0);
			}
		});
		resetbtn.setBounds(63, 355, 112, 30);
		panel.add(resetbtn);
		
		JLabel dateLabel = new JLabel("날짜 입력 : ");
		dateLabel.setForeground(Color.WHITE);
		dateLabel.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		dateLabel.setBounds(63, 125, 120, 35);
		panel.add(dateLabel);
		
		datetf = new JTextField();
		datetf.setBounds(190, 125, 142, 35);
		panel.add(datetf);
		datetf.setColumns(10);
		
		JButton lookup = new JButton("조회");
		lookup.setForeground(Color.BLACK);
		lookup.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		lookup.setBackground(new Color(204, 204, 204));
		lookup.setBounds(344, 130, 75, 30);
		lookup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!(datetf.getText().equals(""))) {
					if(datetf.getText().contains("-")) {
						try {
							boolean datecheck = false;
							rowdata = sd.GetAllSellTotal();
							System.out.println("현재 매출 확인 아이디는 " + rowdata.get(0).saleid);
							for(int i=0; i<rowdata.size(); i++) {
								System.out.println("id는 " + rowdata.get(i).saleid + " 날짜는 " + rowdata.get(i).date
										+ " 총 판매액은 " + rowdata.get(i).total);
								String total [] = new String [3];
								if(saleconfirmid.equals(rowdata.get(i).saleid) && datetf.getText().equals(rowdata.get(i).date)) {
									total[0] = rowdata.get(i).saleid;
									total[1] = rowdata.get(i).date;
									total[2] = rowdata.get(i).total;
									System.out.println(Arrays.toString(total));
									model.addRow(total);
									datecheck = true;
								}
							}
							if(datecheck == false) {
								JOptionPane.showMessageDialog(null,"해당 날짜가 없습니다." + "\n" +
							 "날짜를 다시 확인한 후 YYYY-M-D 또는 YYYY-MM-DD 형식으로 입력해주세요.");
							}
							datecheck = false;
						} catch(Exception ee) {
							ee.printStackTrace();
						}
					} else {
						JOptionPane.showMessageDialog(null,"날짜를 YYYY-M-D 또는 YYYY-MM-DD 형식으로 입력해주세요.");
					}
				} else {
					JOptionPane.showMessageDialog(null,"공백은 사용할 수 없습니다.");
				}  
			}
		});
		panel.add(lookup);
		
		saleconfirmexit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
	}
	public static void main(String[] args) {
		new SalesConfirm();
	}
}