package PosMain;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.ImageIcon;

// 회원가입 프레임 생성
public class MemberSignupp extends JFrame {
	private JPanel contentPane; // 내용
	private JTextField joinID; // 아이디
	private JTextField joinName; // 이름
	private JPasswordField joinPWD; // 패스워드
	ImageIcon icon2;
	boolean isNull = false;
	boolean idchk = false;
	boolean pwchk = false;
	boolean numchk = false;
	
	public MemberSignupp() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\beer.png")); // 회원가입 프레임 생성
		icon2 = new ImageIcon("C:\\\\Users\\\\dahoon\\\\OneDrive - 군산대학교\\\\바탕 화면\\\\소공 프로젝트\\\\signupbackground.png");
		setTitle("POS기 회원가입"); // 타티을 지정
		setBounds(100, 100, 445, 519); // 회원가입 창 사이즈 설정
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		JPanel panel = new JPanel() {
			public void paintComponent(Graphics g) {
				g.drawImage(icon2.getImage(), 0, 0, null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);

		JLabel lblID = new JLabel("");
		lblID.setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\ID.png"));
		lblID.setFont(new Font("맑은 고딕", Font.BOLD, 30));
		lblID.setBounds(87, 133, 100, 50);
		panel.add(lblID);
		joinID = new JTextField();
		joinID.setBounds(174, 148, 144, 30);
		panel.add(joinID);
		joinID.setColumns(10);

		JLabel lblPWD = new JLabel("");
		lblPWD.setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\pw.png"));
		lblPWD.setFont(new Font("맑은 고딕", Font.BOLD, 30));
		lblPWD.setBounds(79, 193, 100, 50);
		panel.add(lblPWD);

		JLabel lblName = new JLabel("");
		lblName.setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\usernum.png"));
		lblName.setFont(new Font("맑은 고딕", Font.BOLD, 25));
		lblName.setBounds(12, 253, 153, 50);
		panel.add(lblName);
		joinName = new JTextField();
		joinName.setBounds(174, 268, 144, 30);
		panel.add(joinName);
		joinName.setColumns(10);

		JButton btnComplete = new JButton(""); 
		btnComplete.setBorderPainted(false);
		btnComplete.setContentAreaFilled(false);
		btnComplete.setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\signupcomplete.png"));
		
		JButton idCheckbtn = new JButton("중복확인");
		idCheckbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean chk;
				boolean idNullchk = true;
				chk = UserDaoo.getInstance().checkID(joinID.getText());
				if(joinID.getText().equals("")) {
					JOptionPane.showMessageDialog(null,  "공백문자는 사용할 수 없습니다...!!");
					idchk = true;
					idNullchk = true;
				} else {
					idNullchk = false;
				}
				if(chk == true && idNullchk == false) {
					JOptionPane.showMessageDialog(null,  "이미 사용중인 아이디입니다...!! 다른 아이디를 사용해주세요.");
					joinID.setText("");
					idchk = false;
					return;
				} else if(idNullchk == false) {
					JOptionPane.showMessageDialog(null,  "사용 가능한 아이디입니다!!!");
					idchk = true;
				}
			}
		});
		idCheckbtn.setFont(new Font("굴림", Font.BOLD, 12));
		idCheckbtn.setBounds(330, 151, 89, 23);
		panel.add(idCheckbtn);
		
		JButton numCheckbtn = new JButton("중복확인");
		numCheckbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean chk;
				boolean numNullchk = true;
				chk = UserDaoo.getInstance().checkNum(joinName.getText());
				if(joinName.getText().equals("")) {
					JOptionPane.showMessageDialog(null,  "공백문자는 사용할 수 없습니다...!!");
					numchk = true;
					numNullchk = true;
				} else {
					numNullchk = false;
				}
				if(chk == true && numNullchk == false) {
					JOptionPane.showMessageDialog(null,  "이미 존재하는 사업자번호입니다.");
					joinName.setText("");
					numchk = false;
					return;
				} else if(numNullchk == false) {
					JOptionPane.showMessageDialog(null,  "사용 가능한 사업자번호입니다!!!");
					numchk = true;
				}
			}
		});
		numCheckbtn.setFont(new Font("굴림", Font.BOLD, 12));
		numCheckbtn.setBounds(330, 270, 89, 23);
		panel.add(numCheckbtn);
		
		// 완료버튼 기능 구현
		btnComplete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int loginOk;
				if((new String(joinPWD.getPassword()).equals("") || joinID.getText().equals("") || joinName.getText().equals(""))){
		            JOptionPane.showMessageDialog(null, "공백문자는 사용할 수 없습니다!");
		            isNull=true;
		        }
				if(new String(joinPWD.getPassword())!="") {
					pwchk = true;
				}
		        if(pwchk==true && idchk == true && numchk == true && isNull==false){
		            loginOk = UserDaoo.getInstance().insert(joinID.getText(), new String(joinPWD.getPassword()), joinName.getText());
		            // TODO add your handling code here:
		            if(loginOk !=0 && idchk == true){
		                JOptionPane.showMessageDialog(null, "회원가입성공");
		                dispose();
		            }
		        } else if(pwchk==true && (idchk == false || numchk == false) && isNull==false){
		            JOptionPane.showMessageDialog(null, "아이디 또는 사업자번호 중복 확인을 해주세요!");
		        }
			}
		});
		btnComplete.setBounds(89, 355, 100, 40);
		panel.add(btnComplete);
		// 취소버튼 기능 구현
		JButton btnCancel = new JButton("");
		btnCancel.setBorderPainted(false);
		btnCancel.setContentAreaFilled(false);
		btnCancel.setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\signupcancel.png"));
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose(); // 회원가입 프레임 중단
			}
		});
		btnCancel.setBounds(245, 355, 100, 40); // 취소버튼
		panel.add(btnCancel);
		joinPWD = new JPasswordField();
		joinPWD.setBounds(174, 208, 144, 30);
		panel.add(joinPWD);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\signuptitle.png"));
		lblNewLabel.setFont(new Font("맑은 고딕", Font.BOLD, 40));
		lblNewLabel.setBounds(144, 49, 166, 65);
		panel.add(lblNewLabel);		
		
		setLocationRelativeTo(null); // 창이 가운데에 나오게
	}
}