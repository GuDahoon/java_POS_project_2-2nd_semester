package PosMain;
// User 데이터의 getter/ setter 함수
public class UserDataa {
	private String id;
	private String pwd;
	private String name;
	public String getId() { // db에서 id를 불러오기 위한 메서드
		return id;
	}
	public void setId(String id) { // id 설정을 위한 메서드
		this.id = id;
	}
	public String getPw() { // db에서 pwd를 불러오기 위한 메서드
		return pwd;
	}
	public void setPw(String pwd) { // pwd 설정을 위한 메서드
		this.pwd = pwd;
	}
	public String getName() { // db에서 name를 불러오기 위한 메서드
		return name;
	}
	public void setName(String name) { // name 설정을 위한 메서드
		this.name = name;
	}
}