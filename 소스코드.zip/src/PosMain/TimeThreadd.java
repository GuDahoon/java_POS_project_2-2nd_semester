package PosMain;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.Calendar;

class TimerThreadd extends Thread {// 시간 클래스
	JLabel timerLabel;
	public TimerThreadd() { // 기본 생성자
	}

	public TimerThreadd(JLabel timerLabel) {
		this.timerLabel = timerLabel;
	}
	@Override
	public void run() {
		while (true) {
			Calendar calendar = Calendar.getInstance();

			int year = calendar.get(Calendar.YEAR);
			int month = calendar.get(Calendar.MONTH) + 1; // Month는 0부터 시작한다.
			int day = calendar.get(Calendar.DATE);
			int hour = calendar.get(Calendar.HOUR_OF_DAY);
			int minute = calendar.get(Calendar.MINUTE);
			int second = calendar.get(Calendar.SECOND);
			String clock = Integer.toString(year) + "-" + Integer.toString(month) + "-" + Integer.toString(day)
					+ " [" + Integer.toString(hour) + ":" + Integer.toString(minute) + ":"
					+ Integer.toString(second) + "]";
			timerLabel.setText(clock);

			try {
				Thread.sleep(1000); // 1초마다 시계를 갱신
			} catch (InterruptedException e) {
				return;
			}
		}
	}
}