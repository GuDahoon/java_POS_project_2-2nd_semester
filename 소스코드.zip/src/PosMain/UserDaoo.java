package PosMain;

import java.awt.EventQueue;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import PosChat.ChatGUIClientt;
import PosChat.ChatGUICounterr;
import PosChat.RunServerThread;

// 마리아db에 접속합니다.
// 그리고 쿼리문을 날리기 위한 PreparedStatement 문을 준비합니다.
public class UserDaoo {
	private static UserDaoo userDao = new UserDaoo(); // 싱글턴 패턴 사용
	// 컴파일 시에 db와 연결된 단 하나의 인스턴스를 생성해서 사용
	public MariaDbConnectt mariaDbConnect = MariaDbConnectt.getInstance(); // 마리아db에 접근
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	UserDataa user;
	ArrayList<UserDataa> userList; // 유저의 데이터 구조체 생성(유저의 데이터가 각자 다르기 떼문에 선언)
	SaleDaoo sd = new SaleDaoo();

	private UserDaoo() { // 기본 생성자
	}
	
	// 싱글톤 함수
	public static UserDaoo getInstance() { // 유저 정보를 객체화 시켜서 
		if (userDao == null) { // null값이면
			userDao = new UserDaoo(); // 새로운 UserDao 객체 생성
		}
		return userDao; // UserDao 리턴해줘서
	}

	// UserData 를 가지고 있는 ArrayList 를 반환
	public ArrayList<UserDataa> select() throws Exception { // user 테이블을 선택 
		con = mariaDbConnect.getConnection(); // 마리아db에 접근
		String sql = "SELECT * FROM testuser"; // 쿼리문
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		userList = new ArrayList<>();
		while (rs.next()) {
			user = new UserDataa();
			user.setId(rs.getString("testid")); // 유저의 id 설정
			user.setPw(rs.getString("testpwd")); // 유저의 pwd 설정
			user.setName(rs.getString("testNum")); // 유저의 name 설정
			userList.add(user); // userList에 user 삽입
		}
		return userList;
	}

	// 회원가입에 성공하게 된다면 발생되는 메소드
	public int insert(String id, String pwd, String BusinessNum) {
		con = mariaDbConnect.getConnection(); // db에 접근
		int loginOk; // 로그인확인을 위한 변수 설정
		try {
			String sql = "INSERT INTO testuser VALUES ('" + id + "','" + pwd + "','" + BusinessNum + "')"; // 쿼리문
			pstmt = con.prepareStatement(sql); // 데이터베이스에서 사용할 SQL 문을 실행
			loginOk = pstmt.executeUpdate(); // 실행 후 없데이트 된 하나의 행 개수 리턴
		} catch (Exception e) {
			return loginOk = 0; 
		}
		return loginOk; 
	}

	// 회원가입된 인원인지 확인하기 위하여 만들어줍니다.
	public boolean loginCheck(String id, String pwd) throws Exception {
		con = mariaDbConnect.getConnection(); // db에 접근
		userList = this.select(); // 
		boolean loginOk = false; // loginOk를 false로 초기화
		for (UserDataa user : userList) {
			if (id.equals(user.getId()) && pwd.equals(user.getPw())) // 만약 입력된 아이디와 비밀번호가 유저의 아이디와 비밀번호와 같으면
				return loginOk = true; // loginOk를 true로 초기화 시켜준다.
		}
		return loginOk; // loginOk 리턴
	}

	public boolean checkID(String id) {
		con = mariaDbConnect.getConnection();
		ResultSet loginOk;
		try {
			String sql = "SELECT count(*) cnt FROM testuser WHERE testid=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				int cnt = rs.getInt("cnt");
				if (cnt > 0) {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
    }
	
	public boolean checkNum(String businessNum) {
		con = mariaDbConnect.getConnection();
		ResultSet loginOk;
		try {
			String sql = "SELECT count(*) cnt FROM testuser WHERE testNum=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, businessNum);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				int cnt = rs.getInt("cnt");
				if (cnt > 0) {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
    }
	
	// 로그인을 성공했을때 발생합니다.
	public void loginSuccess(String id) throws Exception {
		con = mariaDbConnect.getConnection();
		for (UserDataa user : userList) { // 유저리스트의 크기만큼 
			if (id.equals(user.getId())) { // id의 값이 유저의 id 정보와 같은 경우 메인 프로그램을 실행
				String loginName = user.getId(); 
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							MainPoss mp = new MainPoss();
							mp.setId(loginName);
							SaleDaoo sd = new SaleDaoo();
							sd.setuserID(loginName);
							RunServerThread Server1 = new RunServerThread(11110);
					        RunServerThread Server2 = new RunServerThread(11111);
					        RunServerThread Server3 = new RunServerThread(11112);
					        RunServerThread Server4 = new RunServerThread(11113);
					        RunServerThread Server5 = new RunServerThread(11114);
					        RunServerThread Server6 = new RunServerThread(11115);
					        RunServerThread Server7 = new RunServerThread(11116);
					        RunServerThread Server8 = new RunServerThread(11117);
					        
					        Server1.start();
					        Server2.start();
					        Server3.start();
					        Server4.start();
					        Server5.start();
					        Server6.start();
					        Server7.start();
					        Server8.start(); 
					        
					        mp.ChatTable1 = new ChatGUIClientt(11110, 1); 
					        mp.ChatCounter1 = new ChatGUICounterr(11110, 1);
					        
					        mp.ChatTable2 = new ChatGUIClientt(11111, 2);
					        mp.ChatCounter2 = new ChatGUICounterr(11111, 2);
					        
					        mp.ChatTable3 = new ChatGUIClientt(11112, 3);
					        mp.ChatCounter3 = new ChatGUICounterr(11112, 3);
					        
					        mp.ChatTable4 = new ChatGUIClientt(11113, 4);
					        mp.ChatCounter4 = new ChatGUICounterr(11113, 4);
					        
					        mp.ChatTable5 = new ChatGUIClientt(11114, 5);
					        mp.ChatCounter5 = new ChatGUICounterr(11114, 5);
					        
					        mp.ChatTable6 = new ChatGUIClientt(11115, 6);
					        mp.ChatCounter6 = new ChatGUICounterr(11115, 6);
					        
					        mp.ChatTable7 = new ChatGUIClientt(11116, 7);
					        mp.ChatCounter7 = new ChatGUICounterr(11116, 7);
					        
					        mp.ChatTable8 = new ChatGUIClientt(11117, 8);
					        mp.ChatCounter8 = new ChatGUICounterr(11117, 8);   
							System.out.println(loginName);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				break;
			}  
		}
	}
}