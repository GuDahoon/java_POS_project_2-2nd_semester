package PosMain;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Calendar;
import java.util.Vector;
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;

import PosChat.ChatGUIClientt;
import PosChat.ChatGUICounterr;
import PosChat.ChatGUIServer;
import PosChat.RunServerThread;

public class MainPoss extends JFrame {
	static ChatGUIClientt ChatTable1;
	static ChatGUICounterr ChatCounter1;

	static ChatGUIClientt ChatTable2;
	static ChatGUICounterr ChatCounter2;

	static ChatGUIClientt ChatTable3;
	static ChatGUICounterr ChatCounter3;

	static ChatGUIClientt ChatTable4;
	static ChatGUICounterr ChatCounter4;

	static ChatGUIClientt ChatTable5;
	static ChatGUICounterr ChatCounter5;

	static ChatGUIClientt ChatTable6;
	static ChatGUICounterr ChatCounter6;

	static ChatGUIClientt ChatTable7;
	static ChatGUICounterr ChatCounter7;

	static ChatGUIClientt ChatTable8;
	static ChatGUICounterr ChatCounter8;
	   
	SubProgramm sub = new SubProgramm(this, "메뉴 선택");
	ImageIcon MainBackground;
	ImageIcon tableBackground;
	Calendar cal = Calendar.getInstance();
	static String userid;
	
	Vector<Integer> hap = new Vector<Integer>(); // 정산을 위한 Vector 생성
	int hap0, hap1, hap2, hap3, hap4, hap5, hap6, hap7; // 테이블 별 당일 정산 값 설정
	int n0, n1, n2, n3, n4, n5, n6, n7;
	int n, gtn, jki;
	
	JButton exit = new JButton("종료");
	JButton calculate = new JButton("당일정산");
	JButton salesStart = new JButton("영업시작");
	JButton moneyConfirm = new JButton("매출액 확인");
	int sum = 0;
	String todayTotal = ""; // 금일 총 매출액
	String calculateMessage = ""; // 정산 관련 메시지 출력 변수
	boolean btncheck = false;
	boolean calccheck = false;
	boolean endsale = false;
	boolean todaycalc = false; // 당일 정산은 한번만 가능
	
	public void setId(String id) {
		this.userid = id;
		System.out.println(id + "hello it's me");
	}
	
	public MainPoss() {
		this.userid = userid;
		System.out.println(userid);
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\beer.png"));
		MainBackground = new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\mainbackground2.jpg");
		tableBackground = new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\tablepanel.jpg");
		setTitle("Triple H Beer");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
		JPanel mainpanel = new JPanel(){
			public void paintComponent(Graphics g) {
				g.drawImage(MainBackground.getImage(), 0, 0, null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		
		JPanel topleft = new JPanel();
		topleft.setSize(1100, 100);
		topleft.setLocation(0, 0);
		mainpanel.add(topleft);
		JLabel Title = new JLabel("Triple H Beer");
		Title.setForeground(Color.WHITE);
		topleft.add(Title);
		topleft.setBackground(new Color(255, 0, 0, 0));
		Title.setFont(new Font("Algerian", Font.BOLD, 60));
		
		
		JPanel topright = new JPanel();
		topright.setSize(500, 100);
		topright.setLocation(1100, 0);
		topright.setBackground(new Color(0, 0, 0));
		mainpanel.add(topright);
		JLabel Clock = new JLabel("");
		Clock.setForeground(Color.WHITE);
		topright.add(Clock);
		TimerThreadd timer = new TimerThreadd(Clock);
		Clock.setFont(new Font("한컴바탕", Font.BOLD, 27));
		
		
		JPanel bottomleft = new JPanel();
		bottomleft.setLayout(new BorderLayout()); 
		bottomleft.setSize(1100, 700);
		bottomleft.setLocation(0, 150);
		bottomleft.setBackground(new Color(255, 0, 0, 0));
		mainpanel.add(bottomleft);
		JPanel blTop = new JPanel(); 
		blTop.setBackground(new Color(255,0,0,0));
		bottomleft.add(blTop, BorderLayout.NORTH);
		JPanel blCenter = new JPanel(); 
		blCenter.setBackground(new Color(255,0,0,0));
		bottomleft.add(blCenter, BorderLayout.CENTER);
		JPanel blBottom = new JPanel();
		blBottom.setBackground(new Color(255,0,0,0));
		bottomleft.add(blBottom, BorderLayout.SOUTH);
		
		
		JPanel bottomright = new JPanel();
		bottomright.setLayout(new BorderLayout());
		bottomright.setSize(500, 750);
		bottomright.setLocation(1100, 100);
		bottomright.setBackground(new Color(255, 0, 0, 0));
		JPanel nullbottom = new JPanel();
		bottomright.add(nullbottom, BorderLayout.NORTH);
		nullbottom.setBackground(new Color(255, 0, 0, 0));
		
		JPanel brTop = new JPanel();
		bottomright.add(brTop, BorderLayout.CENTER);
		brTop.setBackground(new Color(255, 0, 0, 0));
		brTop.setLayout(new BorderLayout());
		JPanel brtTop = new JPanel();
		brTop.add(brtTop, BorderLayout.NORTH);
		brtTop.setBackground(new Color(255, 0, 0, 0));
		JPanel brtBottom = new JPanel();
		brTop.add(brtBottom, BorderLayout.CENTER);
		brtBottom.setBackground(new Color(255, 0, 0, 0));
		
		JPanel brBottom = new JPanel();
		bottomright.add(brBottom, BorderLayout.SOUTH);
		brBottom.setBackground(new Color(255, 0, 0, 0));
		brBottom.setLayout(new BorderLayout());
		JPanel brbTop = new JPanel();
		brBottom.add(brbTop, BorderLayout.NORTH);
		brbTop.setBackground(new Color(255, 0, 0, 0));
		JPanel brbBottom = new JPanel();
		brBottom.add(brbBottom, BorderLayout.SOUTH);
		brbBottom.setBackground(new Color(255, 0, 0, 0));
		
		mainpanel.add(bottomright);
		
		
		JPanel[] pay = { new JPanel(), new JPanel(), new JPanel(), new JPanel(), new JPanel(), new JPanel(), new JPanel(),
				new JPanel() };
		for(int i=0; i<pay.length; i++) {
			pay[i].setBackground(new Color(204,204,204));
		}
		// 결제 버튼 생성
		JButton[] moneypaybtn = { new JButton(""),new JButton(""),new JButton(""),new JButton(""),new JButton(""),new JButton(""),
				new JButton(""),new JButton("")};
		for(int i=0; i<moneypaybtn.length; i++) {
			moneypaybtn[i].setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\money.png"));
			moneypaybtn[i].setBorderPainted(false);
			moneypaybtn[i].setContentAreaFilled(false);
		}
		JButton[] cardpaybtn = {new JButton(""),new JButton(""),new JButton(""),new JButton(""),new JButton(""),new JButton(""),
				new JButton(""),new JButton("")};
		for(int i=0; i<cardpaybtn.length; i++) {
			cardpaybtn[i].setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\card.png"));
			cardpaybtn[i].setBorderPainted(false);
			cardpaybtn[i].setContentAreaFilled(false);
		}
		// 테이블 생성
		JTextArea[] table = { new JTextArea(7,15),new JTextArea(7,15),new JTextArea(7,15),new JTextArea(7,15),new JTextArea(7,15),
				new JTextArea(7,15),new JTextArea(7,15),new JTextArea(7,15)};
		// 각 테이블에 들어가는 스크롤 바 생성
		JScrollPane[] tableScroll = { new JScrollPane(table[0]),new JScrollPane(table[1]),new JScrollPane(table[2]),new JScrollPane(table[3]),
				new JScrollPane(table[4]),new JScrollPane(table[5]),new JScrollPane(table[6]),new JScrollPane(table[7])};
		// 가격이 들어갈 money 필드 생성
		JTextField[] money = { new JTextField("0원", 10),new JTextField("0원", 10),new JTextField("0원", 10),new JTextField("0원", 10),
				new JTextField("0원", 10),new JTextField("0원", 10),new JTextField("0원", 10),new JTextField("0원", 10)};
		// 각 테이블별 라벨 값 생성
		JLabel[] tableNumber = { new JLabel("1번"),new JLabel("2번"),new JLabel("3번"),new JLabel("4번"),new JLabel("5번"),new JLabel("6번"),
				new JLabel("7번"),new JLabel("8번")};
		
		JPanel[] messagepl = {new JPanel(),new JPanel(),new JPanel(),new JPanel(),new JPanel(),new JPanel(),new JPanel(),
				new JPanel()};
		for(int i=0; i<messagepl.length; i++) {
			messagepl[i].setBackground(new Color(102,102,102));
		}
		JButton[] messagebtn = {new JButton(),new JButton(),new JButton(),new JButton(),new JButton(),new JButton(),
				new JButton(),new JButton()};
		for(int i=0; i<messagebtn.length; i++) {
			messagebtn[i].setIcon(new ImageIcon("C:\\Users\\dahoon\\OneDrive - 군산대학교\\바탕 화면\\소공 프로젝트\\message.png"));
			messagebtn[i].setBorderPainted(false);
			messagebtn[i].setContentAreaFilled(false);
		}
		
		JTextField memo = new JTextField(15);
		JTextArea memoArea = new JTextArea(30, 10);	
		nullbottom.setLayout(new BorderLayout());
		JLabel label = new JLabel("메모장");
		label.setForeground(new Color(255, 255, 255));
		label.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		nullbottom.add(label, BorderLayout.NORTH);
		nullbottom.add(memoArea, BorderLayout.SOUTH);
		
		table[0].addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				} else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					sub.setVisible(true);
					String mainTotalFld = sub.getInputTotalFld();
					String mainMenuTotal = sub.getInputMenuTotal();
					JTextArea table = (JTextArea) e.getSource();
					table.append(mainMenuTotal);
					sub.n = "";
					if (mainTotalFld != null) {
						int total0 = Integer.parseInt(mainTotalFld);
						hap0 += total0;
						hap.add(hap0);
						sub.totalFld.setText("");
						String total0h = Integer.toString(hap0) + "원";
						money[0].setText(total0h);
					}
				}
			}
		});
		table[1].addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					sub.setVisible(true);
					String mainTotalFld = sub.getInputTotalFld();
					String mainMenuTotal = sub.getInputMenuTotal();
					JTextArea table = (JTextArea) e.getSource();
					table.append(mainMenuTotal);
					sub.n = "";
					if (mainTotalFld != null) {
						int total1 = Integer.parseInt(mainTotalFld);
						hap1 += total1;
						hap.add(hap1);
						sub.totalFld.setText("");
						String total1h = Integer.toString(hap1) + "원";
						money[1].setText(total1h);
					}
				}
			}
		});
		table[2].addMouseListener(new MouseAdapter() { // 3번 테이블 리스너 설정
			public void mouseClicked(MouseEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					sub.setVisible(true);
					String mainTotalFld = sub.getInputTotalFld();
					String mainMenuTotal = sub.getInputMenuTotal();
					JTextArea table = (JTextArea) e.getSource();
					table.append(mainMenuTotal);
					sub.n = "";
					if (mainTotalFld != null) {
						int total2 = Integer.parseInt(mainTotalFld);
						hap2 += total2;
						hap.add(hap2);
						sub.totalFld.setText("");
						String total2h = Integer.toString(hap2) + "원";
						money[2].setText(total2h);
					}
				}
			}
		});
		table[3].addMouseListener(new MouseAdapter() { // 4번 테이블 리스너 설정
			public void mouseClicked(MouseEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					sub.setVisible(true);
					String mainTotalFld = sub.getInputTotalFld();
					String mainMenuTotal = sub.getInputMenuTotal();
					JTextArea table = (JTextArea) e.getSource();
					table.append(mainMenuTotal);
					sub.n = "";
					if (mainTotalFld != null) {
						int total3 = Integer.parseInt(mainTotalFld);
						hap3 += total3;
						hap.add(hap3);
						sub.totalFld.setText("");
						String total3h = Integer.toString(hap3) + "원";
						money[3].setText(total3h);
					}
				}
			}
		});
		table[4].addMouseListener(new MouseAdapter() { // 5번 테이블 리스너 설정
			public void mouseClicked(MouseEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					sub.setVisible(true);
					String mainTotalFld = sub.getInputTotalFld();
					String mainMenuTotal = sub.getInputMenuTotal();
					JTextArea table = (JTextArea) e.getSource();
					table.append(mainMenuTotal);
					sub.n = "";
					if (mainTotalFld != null) {
						int total4 = Integer.parseInt(mainTotalFld);
						hap4 += total4;
						hap.add(hap4);
						sub.totalFld.setText("");
						String total4h = Integer.toString(hap4) + "원";
						money[4].setText(total4h);
					}
				}
			}
		});
		table[5].addMouseListener(new MouseAdapter() { // 6번 테이블 리스너 설정
			public void mouseClicked(MouseEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					sub.setVisible(true);
					String mainTotalFld = sub.getInputTotalFld();
					String mainMenuTotal = sub.getInputMenuTotal();
					JTextArea table = (JTextArea) e.getSource();
					table.append(mainMenuTotal);
					sub.n = "";
					if (mainTotalFld != null) {
						int total5 = Integer.parseInt(mainTotalFld);
						hap5 += total5;
						hap.add(hap5);
						sub.totalFld.setText("");
						String total5h = Integer.toString(hap5) + "원";
						money[5].setText(total5h);
					}
				}
			}
		});
		table[6].addMouseListener(new MouseAdapter() { // 7번 테이블 리스너 설정
			public void mouseClicked(MouseEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					sub.setVisible(true);
					String mainTotalFld = sub.getInputTotalFld();
					String mainMenuTotal = sub.getInputMenuTotal();
					JTextArea table = (JTextArea) e.getSource();
					table.append(mainMenuTotal);
					sub.n = "";
					if (mainTotalFld != null) {
						int total6 = Integer.parseInt(mainTotalFld);
						hap6 += total6;
						hap.add(hap6);
						sub.totalFld.setText("");
						String total6h = Integer.toString(hap6) + "원";
						money[6].setText(total6h);
					}
				}
			}
		});
		table[7].addMouseListener(new MouseAdapter() { // 8번 테이블 리스너 설정
			public void mouseClicked(MouseEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					sub.setVisible(true);
					String mainTotalFld = sub.getInputTotalFld();
					String mainMenuTotal = sub.getInputMenuTotal();
					JTextArea table = (JTextArea) e.getSource();
					table.append(mainMenuTotal);
					sub.n = "";
					if (mainTotalFld != null) {
						int total7 = Integer.parseInt(mainTotalFld);
						hap7 += total7;
						hap.add(hap7);
						sub.totalFld.setText("");
						String total7h = Integer.toString(hap7) + "원";
						money[7].setText(total7h);
					}
				}
			}
		});
		
		
		moneypaybtn[0].addActionListener(new ActionListener() { // 1번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap0 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap0; // sum의 주문
						hap.add(hap0);
						sub.totalFld.setText("");
						hap0 = 0;
						String total0h = Integer.toString(hap0) + "원";
						money[0].setText(total0h);
						table[0].setText("");
					}
				}
			}
		});
		moneypaybtn[1].addActionListener(new ActionListener() { // 2번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap1 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap1; // sum의 주문
						hap.add(hap1);
						sub.totalFld.setText("");
						hap1 = 0;
						String total1h = Integer.toString(hap1) + "원";
						money[1].setText(total1h);
						table[1].setText("");
					}
				}
			}
		});
		moneypaybtn[2].addActionListener(new ActionListener() { // 3번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				} else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				}else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap2 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap2; // sum의 주문
						hap.add(hap2);
						sub.totalFld.setText("");
						hap2 = 0;
						String total0h = Integer.toString(hap2) + "원";
						money[2].setText(total0h);
						table[2].setText("");
					}
				}
			}
		});
		moneypaybtn[3].addActionListener(new ActionListener() { // 4번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap3 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap3; // sum의 주문
						hap.add(hap3);
						sub.totalFld.setText("");
						hap3 = 0;
						String total3h = Integer.toString(hap3) + "원";
						money[3].setText(total3h);
						table[3].setText("");
					}
				}
			}
		});
		moneypaybtn[4].addActionListener(new ActionListener() { // 5번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap4 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap4; // sum의 주문
						hap.add(hap4);
						sub.totalFld.setText("");
						hap4 = 0;
						String total4h = Integer.toString(hap4) + "원";
						money[4].setText(total4h);
						table[4].setText("");
					}
				}
			}
		});
		moneypaybtn[5].addActionListener(new ActionListener() { // 6번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap5 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap5; // sum의 주문
						hap.add(hap5);
						sub.totalFld.setText("");
						hap5 = 0;
						String total5h = Integer.toString(hap5) + "원";
						money[5].setText(total5h);
						table[5].setText("");
					}
				}
			}
		});
		moneypaybtn[6].addActionListener(new ActionListener() { // 7번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap6 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap6; // sum의 주문
						hap.add(hap6);
						sub.totalFld.setText("");
						hap6 = 0;
						String total6h = Integer.toString(hap6) + "원";
						money[6].setText(total6h);
						table[6].setText("");
					}
				}
			}
		});
		moneypaybtn[7].addActionListener(new ActionListener() { // 8번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap7 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap7; // sum의 주문
						hap.add(hap7);
						sub.totalFld.setText("");
						hap7 = 0;
						String total7h = Integer.toString(hap0) + "원";
						money[7].setText(total7h);
						table[7].setText("");
					}
				}
			}
		});
		
		
		cardpaybtn[0].addActionListener(new ActionListener() { // 1번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap0 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap0; // sum의 주문
						hap.add(hap0);
						sub.totalFld.setText("");
						hap0 = 0;
						String total0h = Integer.toString(hap0) + "원";
						money[0].setText(total0h);
						table[0].setText("");
					}
				}
			}
		});
		cardpaybtn[1].addActionListener(new ActionListener() { // 2번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap1 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap1; // sum의 주문
						hap.add(hap1);
						sub.totalFld.setText("");
						hap1 = 0;
						String total1h = Integer.toString(hap1) + "원";
						money[1].setText(total1h);
						table[1].setText("");
					}
				}
			}
		});
		cardpaybtn[2].addActionListener(new ActionListener() { // 3번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap2 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap2; // sum의 주문
						hap.add(hap2);
						sub.totalFld.setText("");
						hap2 = 0;
						String total0h = Integer.toString(hap2) + "원";
						money[2].setText(total0h);
						table[2].setText("");
					}
				}
			}
		});
		cardpaybtn[3].addActionListener(new ActionListener() { // 4번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap3 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap3; // sum의 주문
						hap.add(hap3);
						sub.totalFld.setText("");
						hap3 = 0;
						String total3h = Integer.toString(hap3) + "원";
						money[3].setText(total3h);
						table[3].setText("");
					}
				}
			}
		});
		cardpaybtn[4].addActionListener(new ActionListener() { // 5번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap4 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap4; // sum의 주문
						hap.add(hap4);
						sub.totalFld.setText("");
						hap4 = 0;
						String total4h = Integer.toString(hap4) + "원";
						money[4].setText(total4h);
						table[4].setText("");
					}
				}
			}
		});
		cardpaybtn[5].addActionListener(new ActionListener() { // 6번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap5 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap5; // sum의 주문
						hap.add(hap5);
						sub.totalFld.setText("");
						hap5 = 0;
						String total5h = Integer.toString(hap5) + "원";
						money[5].setText(total5h);
						table[5].setText("");
					}
				}
			}
		});
		cardpaybtn[6].addActionListener(new ActionListener() { // 7번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap6 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap6; // sum의 주문
						hap.add(hap6);
						sub.totalFld.setText("");
						hap6 = 0;
						String total6h = Integer.toString(hap6) + "원";
						money[6].setText(total6h);
						table[6].setText("");
					}
				}
			}
		});
		cardpaybtn[7].addActionListener(new ActionListener() { // 8번 테이블의 결제 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if(btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				}else if(todaycalc == true) {
					JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "현재 금액은 " + hap7 + "원 입니다." + "결제 하시겠습니까?", "결제 확인",
							JOptionPane.YES_NO_OPTION); // 생성매개변수로 뜨워지는 창에 옵션으로 yes, no 버튼 보여짐 
					if (result == JOptionPane.YES_OPTION) { // 만약 result 값이 yes option이면
						sum += hap7; // sum의 주문
						hap.add(hap7);
						sub.totalFld.setText("");
						hap7 = 0;
						String total7h = Integer.toString(hap0) + "원";
						money[7].setText(total7h);
						table[7].setText("");
					}
				}
			}
		});
		
		messagebtn[0].addActionListener(new ActionListener() { // 1번 테이블의 채팅 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				} else {
					ChatCounter1.setBounds(200, 200, 372, 497);
					ChatCounter1.setVisible(true);
				}
			}
		});
		messagebtn[1].addActionListener(new ActionListener() { // 2번 테이블의 채팅 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				} else {
					ChatCounter2.setBounds(200, 200, 372, 497);
					ChatCounter2.setVisible(true);
				}
			}
		});
		messagebtn[2].addActionListener(new ActionListener() { // 3번 테이블의 채팅 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				} else {
					ChatCounter3.setBounds(200, 200, 372, 497);
					ChatCounter3.setVisible(true);
				}
			}
		});
		messagebtn[3].addActionListener(new ActionListener() { // 4번 테이블의 채팅 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				} else {
					ChatCounter4.setBounds(200, 200, 372, 497);
					ChatCounter4.setVisible(true);
				}
			}
		});
		messagebtn[4].addActionListener(new ActionListener() { // 5번 테이블의 채팅 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				} else {
					ChatCounter5.setBounds(200, 200, 372, 497);
					ChatCounter5.setVisible(true);
				}
			}
		});
		messagebtn[5].addActionListener(new ActionListener() { // 6번 테이블의 채팅 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				} else {
					ChatCounter6.setBounds(200, 200, 372, 497);
					ChatCounter6.setVisible(true);
				}
			}
		});
		messagebtn[6].addActionListener(new ActionListener() { // 7번 테이블의 채팅 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				} else {
					ChatCounter7.setBounds(200, 200, 372, 497);
					ChatCounter7.setVisible(true);
				}
			}
		});
		messagebtn[7].addActionListener(new ActionListener() { // 8번 테이블의 채팅 버튼 리스너 설정
			@Override
			public void actionPerformed(ActionEvent e) {
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				} else {
					ChatCounter8.setBounds(200, 200, 372, 497);
					ChatCounter8.setVisible(true);
				}
			}
		});

		for (int i = 0; i < 4; i++) {
			JPanel AllTable = new JPanel(){
				public void paintComponent(Graphics g) {
					g.drawImage(tableBackground.getImage(), 0, 0, null);
					setOpaque(false);
					super.paintComponent(g);
				}
			};
			AllTable.setLayout(new BorderLayout());
			JPanel TopTable = new JPanel();
			TopTable.setBackground(new Color(153,153,153));
			AllTable.add(TopTable, BorderLayout.NORTH);
			JPanel CenterTable = new JPanel();
			CenterTable.setBackground(new Color(255,0,0,0));
			AllTable.add(CenterTable, BorderLayout.CENTER);
			JPanel BottomTable = new JPanel();
			BottomTable.setBackground(new Color(255,0,0,0));
			AllTable.add(BottomTable, BorderLayout.SOUTH);
			BottomTable.setLayout(new BorderLayout());
			JPanel btTop = new JPanel();
			btTop.setBackground(new Color(255,0,0,0));
			BottomTable.add(btTop, BorderLayout.NORTH);
			JPanel btBottom = new JPanel();
			btBottom.setBackground(new Color(255,0,0,0));
			BottomTable.add(btBottom, BorderLayout.SOUTH);
			blTop.add(AllTable);
			
			pay[i].add(tableNumber[i]);
			pay[i].add(moneypaybtn[i]);
			pay[i].add(cardpaybtn[i]);
			pay[i].setFont(new Font("한컴바탕", Font.ITALIC, 15));
			messagepl[i].add(messagebtn[i]);
			table[i].setCaretPosition(table[i].getDocument().getLength());
			CenterTable.add(tableScroll[i]);
			btTop.add(pay[i]);
			btBottom.add(messagepl[i]);
			TopTable.add(new JLabel("총 가격:"));
			TopTable.add(money[i]);
		}
		
		for (int i = 4; i < 8; i++) {
			JPanel AllTable = new JPanel(){
				public void paintComponent(Graphics g) {
					g.drawImage(tableBackground.getImage(), 0, 0, null);
					setOpaque(false);
					super.paintComponent(g);
				}
			};
			AllTable.setLayout(new BorderLayout());
			JPanel TopTable = new JPanel();
			TopTable.setBackground(new Color(153,153,153));
			AllTable.add(TopTable, BorderLayout.NORTH);
			JPanel CenterTable = new JPanel();
			CenterTable.setBackground(new Color(255,0,0,0));
			AllTable.add(CenterTable, BorderLayout.CENTER);
			JPanel BottomTable = new JPanel();
			BottomTable.setBackground(new Color(255,0,0,0));
			AllTable.add(BottomTable, BorderLayout.SOUTH);
			BottomTable.setLayout(new BorderLayout());
			JPanel btTop = new JPanel();
			btTop.setBackground(new Color(255,0,0,0));
			BottomTable.add(btTop, BorderLayout.NORTH);
			JPanel btBottom = new JPanel();
			btBottom.setBackground(new Color(255,0,0,0));
			BottomTable.add(btBottom, BorderLayout.SOUTH);
			blBottom.add(AllTable);
			
			pay[i].add(tableNumber[i]);
			pay[i].add(moneypaybtn[i]);
			pay[i].add(cardpaybtn[i]);
			pay[i].setFont(new Font("한컴바탕", Font.ITALIC, 15));
			messagepl[i].add(messagebtn[i]);
			table[i].setCaretPosition(table[i].getDocument().getLength());
			CenterTable.add(tableScroll[i]);
			btTop.add(pay[i]);
			btBottom.add(messagepl[i]);
			TopTable.add(new JLabel("총 가격:"));
			TopTable.add(money[i]);
		}
		calculate.setBackground(new Color(204, 204, 204));
		calculate.setFont(new Font("맑은 고딕", Font.BOLD, 30));
		
		calculate.addActionListener(new ActionListener() { 
			@Override
			public void actionPerformed(ActionEvent arg0) {
				int saleOk;
				if (btncheck == false) {
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				} else {
					if(todaycalc == false) {
						if (sum != 0) { // 만약 sum이 0이 아니면
							for (int i = 0; i < hap.size(); i++) { // hap사이즈만큼 반복문을 돌면서
								gtn = hap.elementAt(i); // 정산된 hap값을 gtn에 저장
								jki += gtn; // 
							}
							System.out.println("n의값:" + jki);
							todayTotal = Integer.toString(sum);
							System.out.println("벡터에 저장된 값 :" + gtn);
							calculateMessage = "현재 매출액은 " + todayTotal + "원 입니다";
							JOptionPane.showMessageDialog(null, calculateMessage);
						} else {
							JOptionPane.showMessageDialog(null, "금일 매출은 0원입니다...ㅠㅠㅠ");
						}
						int year = cal.get(cal.YEAR);
						int month = cal.get(cal.MONTH)+1;
						int date = cal.get(cal.DATE);
						String today = year + "-" + month + "-" + date;
						saleOk = SaleDaoo.getInstance().insert(userid,today, new String(todayTotal));
						calccheck = true;
						todaycalc = true;
					} else {
						JOptionPane.showMessageDialog(null, "이미 정산을 진행하셨습니다.");
					}
				}
			}
		});
		salesStart.setFont(new Font("맑은 고딕", Font.BOLD, 30));
		salesStart.setBackground(new Color(204, 204, 204));
		
		
		salesStart.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JButton b = (JButton) e.getSource(); // getSource() 메소드를 통해 이벤트를 발생시킨 이벤트 소스 객체를 가져옴
				if (b.getText().equals("영업시작")) { // 버튼 b의 텍스트가 영업시작과 같으면
					String startTime = Clock.getText(); // 시간을 얻어서
					String startTotal = "금일 영업 시작 시간은 " + startTime + " 입니다." + "\n"
										+ "              모든 기능을 활성화합니다."; // total 저장
					JOptionPane.showMessageDialog(null, startTotal); // 출력
					b.setText("영업종료"); // 버튼의 텍스트 값을 영업종료로 변경
					btncheck = true;
				} else { // 영업종료일 경우
					if(calccheck == false) {
						JOptionPane.showMessageDialog(null, "정산을 진행해주세요!!!!!");
					} else {
						String finishTime = Clock.getText();
						String finishTotal = "금일 영업 종료 시간은  " + finishTime + " 입니다." + "\n" + "수고하셨습니다!";
						JOptionPane.showMessageDialog(null, finishTotal);
						b.setText("영업시작");
						sum = 0;
						btncheck = false;
						calccheck = false;
						todaycalc = false;
					}
				}
			}
		});
		brtTop.add(salesStart);
		brtBottom.add(calculate);
		moneyConfirm.setBackground(new Color(204, 204, 204));
		moneyConfirm.setFont(new Font("맑은 고딕", Font.BOLD, 30));
		
		
		moneyConfirm.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				SalesConfirm sc = new SalesConfirm(userid);
				if (btncheck == false) {
					sc.setVisible(false);
					JOptionPane.showMessageDialog(null, "영업을 시작해주세요!!!!");
				} else {
					sc.setVisible(true);
				}
			}
		});
		brbTop.add(moneyConfirm);
		exit.setBackground(new Color(204, 204, 204));
		exit.setFont(new Font("맑은 고딕", Font.BOLD, 30));
		
		
		exit.addActionListener(new ActionListener() { // 종료버튼 이벤트 처리
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0); // 시스템 종료
			}
		});
		brbBottom.add(exit);
		

		getContentPane().add(mainpanel, BorderLayout.CENTER);
		mainpanel.setLayout(null);
		
		JLabel versionlabel = new JLabel("Version : 0.0.3a");
		versionlabel.setForeground(new Color(240, 248, 255));
		versionlabel.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		versionlabel.setBounds(1286, 898, 196, 27);
		mainpanel.add(versionlabel);
		
		JLabel posmade = new JLabel("제작자 : 구다훈 김덕형 박재현");
		posmade.setForeground(new Color(240, 248, 255));
		posmade.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		posmade.setBounds(12, 898, 278, 33);
		mainpanel.add(posmade);
		timer.start();
		
		setVisible(true);
		setSize(1500,1000);
		setResizable(false);
		setLocationRelativeTo(null);
	}
	public static void main(String[] args) {
		new MainPoss(); 
	}
}