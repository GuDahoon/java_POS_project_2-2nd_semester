package PosChat;

public class RunServerThread extends Thread{
	private int port;
	
	public RunServerThread(int port) {
		this.port = port;
	}
	public void run() {
		new ChatGUIServer(port);
	}
}